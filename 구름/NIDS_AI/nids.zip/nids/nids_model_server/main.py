import os
import time
import logging
import warnings
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from scapy.all import rdpcap
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import joblib

app = FastAPI()

# 경고 메시지 제거 설정
warnings.filterwarnings("ignore", category=UserWarning, module='sklearn')

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 모델 로드
logger.info("Loading model...")
model = joblib.load('Behavior_based_detection_NIDS_v1.pkl')
logger.info("Model loaded successfully.")

# PCAP 파일 저장 디렉터리
PCAP_DIR = "/pcap-data"
os.makedirs(PCAP_DIR, exist_ok=True)

# 전역 변수로 패킷 데이터와 예측 결과 저장
latest_predictions_log = []

# 템플릿 설정
templates = Jinja2Templates(directory="templates")

class PcapFileHandler(FileSystemEventHandler):
    def on_created(self, event):
        if event.is_directory:
            return
        if event.src_path.endswith(".pcap"):
            logger.info(f"New PCAP file detected: {event.src_path}")
            
            # 파일 생성 후 대기 (파일이 완전히 쓰여지도록)
            time.sleep(5)
            
            analyze_pcap(event.src_path)

def analyze_pcap(pcap_file):
    global latest_predictions_log

    try:
        packets = rdpcap(pcap_file)
    except Exception as e:
        logger.error(f"Failed to read PCAP file: {e}")
        return

    for packet in packets:
        features = extract_features(packet)
        try:
            prediction = model.predict([features])[0]
        except Exception as e:
            logger.error(f"Failed to predict with features {features}: {e}")
            continue

        # 패킷 정보, 예측 값 및 피처를 로그 형식으로 저장
        log_entry = f"Prediction: {prediction}, Packet: {packet.summary()}, Features: {features}"
        latest_predictions_log.append(log_entry)

        # 로그 출력
        logger.info(log_entry)

# 변수 추출 함수 구현
def extract_features(packet):
    src_bytes = len(packet)
    dst_bytes = 0
    same_srv_count = 0
    dst_host_srv_count = 0

    src_ip_counter = {}
    dst_ip_counter = {}
    same_srv_counter = {}
    dst_host_srv_counter = {}

    if packet.haslayer('IP'):
        ip_layer = packet['IP']
        src_ip = ip_layer.src
        dst_ip = ip_layer.dst
        pkt_len = len(packet)

        # src_bytes와 dst_bytes 추출
        src_bytes += pkt_len
        dst_bytes += pkt_len

        src_ip_counter[src_ip] = src_ip_counter.get(src_ip, 0) + 1
        dst_ip_counter[dst_ip] = dst_ip_counter.get(dst_ip, 0) + 1

        # same_srv_count 추출 (같은 목적지 포트로 향하는 패킷 수)
        if packet.haslayer('TCP'):
            dst_port = packet['TCP'].dport
            if dst_ip not in same_srv_counter:
                same_srv_counter[dst_ip] = {}
            if dst_port not in same_srv_counter[dst_ip]:
                same_srv_counter[dst_ip][dst_port] = 0
            same_srv_counter[dst_ip][dst_port] += 1

            same_srv_count = max(same_srv_counter[dst_ip].values())

        # dst_host_srv_count 추출 (특정 목적지 IP로 향하는 패킷 수)
        if dst_ip not in dst_host_srv_counter:
            dst_host_srv_counter[dst_ip] = 0
        dst_host_srv_counter[dst_ip] += 1

        dst_host_srv_count = max(dst_host_srv_counter.values())

    return [src_bytes, dst_bytes, same_srv_count, dst_host_srv_count]

@app.get("/")
def read_root():
    return {"Hello": "World"}

@app.get("/results", response_class=HTMLResponse)
async def get_results(request: Request):
    global latest_predictions_log
    return templates.TemplateResponse("results.html", {"request": request, "logs": latest_predictions_log})

@app.get("/health")
def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    import threading

    # 파일 시스템 감시 설정
    event_handler = PcapFileHandler()
    observer = Observer()
    observer.schedule(event_handler, PCAP_DIR, recursive=False)
    observer.start()

    # FastAPI 서버 시작
    uvicorn.run(app, host="0.0.0.0", port=8000)

    # 감시 중지 시 처리
    observer.stop()
    observer.join()
