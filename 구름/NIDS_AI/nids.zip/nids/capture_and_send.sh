#!/bin/bash

PCAP_DIR="/pcap-data"  # pcap 파일을 저장할 공유 볼륨 디렉터리

# pcap 파일을 저장할 디렉터리 생성 (존재하지 않으면)
mkdir -p $PCAP_DIR

# 로그 메시지 출력 함수
log_message() {
    local message="$1"
    echo "$(date +"%Y-%m-%d %H:%M:%S") $message"
}

capture_pcap() {
    local filename=$1
    local duration=5  # 캡처 지속 시간 (초)
    local filepath="$PCAP_DIR/$filename"

    # 패킷 캡처 시작 로그
    log_message "Starting packet capture: $filename"

    # tcpdump를 사용하여 패킷 캡처 및 파일 저장
    tcpdump -i eth0 -w "$filepath" -G $duration -W 1

    # 패킷 캡처 완료 로그
    log_message "Packet capture completed: $filename"
}

while true; do
    # 현재 타임스탬프를 기반으로 파일 이름 생성
    timestamp=$(date +"%Y%m%d_%H%M%S")
    filename="capture_$timestamp.pcap"

    # 패킷 캡처 및 파일 저장
    capture_pcap $filename

    # 다음 캡처까지 대기 시간 (예: 5초)
    sleep 5
done
